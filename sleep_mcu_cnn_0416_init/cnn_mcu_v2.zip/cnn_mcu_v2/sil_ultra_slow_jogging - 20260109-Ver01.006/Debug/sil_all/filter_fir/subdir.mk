################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../sil_all/filter_fir/sil_filter_fir.c 

C_DEPS += \
./sil_all/filter_fir/sil_filter_fir.d 

OBJS += \
./sil_all/filter_fir/sil_filter_fir.o 

SREC += \
sil_ultra_slow_jogging.srec 

MAP += \
sil_ultra_slow_jogging.map 


# Each subdirectory must supply rules for building sources it contributes
sil_all/filter_fir/%.o: ../sil_all/filter_fir/%.c
	$(file > $@.in,-mcpu=cortex-m33 -mthumb -mfloat-abi=hard -mfpu=fpv5-sp-d16 -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_ORDINAL=1 -DQE_TOUCH_CONFIGURATION -D_RA_CORE=CM33 -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra_gen" -I"." -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra_cfg/fsp_cfg/bsp" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra_cfg/fsp_cfg" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/src" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/sil_all" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/fsp/inc" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/fsp/inc/api" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/fsp/inc/instances" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/qe_gen" -std=c99 -Wno-stringop-overflow -Wno-format-truncation --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

