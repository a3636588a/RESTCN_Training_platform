################################################################################
# Automatically-generated file. Do not edit!
################################################################################

ASM_UPPER_SRCS := 
O_SRCS := 
ELF_SRCS := 
SX_SRCS := 
LINKER_SCRIPT := 
JMP_UPPER_SRCS := 
P_UPPER_SRCS := 
SRC_SRCS := 
JMP_SRCS := 
FSY_UPPER_SRCS := 
PP_UPPER_SRCS := 
OBJ_UPPER_SRCS := 
ASM_SRCS := 
SX_UPPER_SRCS := 
O_UPPER_SRCS := 
S_UPPER_SRCS := 
ELF_UPPER_SRCS := 
C_UPPER_SRCS := 
OBJ_SRCS := 
S_SRCS := 
PP_SRCS := 
SRC_UPPER_SRCS := 
FSY_SRCS := 
P_SRCS := 
C_SRCS := 
JMP_DEPS := 
FSY_DEPS := 
C_UPPER_DEPS := 
SECONDARY_SIZE := 
SRC_UPPER_DEPS := 
P_UPPER_DEPS := 
S_DEPS := 
PP_UPPER_DEPS := 
P_DEPS := 
FSY_UPPER_DEPS := 
C_DEPS := 
SRC_DEPS := 
JMP_UPPER_DEPS := 
PP_DEPS := 
SX_DEPS := 
ASM_UPPER_DEPS := 
SX_UPPER_DEPS := 
OBJS := 
SECONDARY_FLASH := 
ASM_DEPS := 
SREC := 
S_UPPER_DEPS := 
MAP := 

# Every subdirectory with source files must be described here
SUBDIRS := \
qe_gen \
ra/fsp/src/bsp/cmsis/Device/RENESAS/Source \
ra/fsp/src/bsp/mcu/all \
ra/fsp/src/bsp/mcu/ra6m5 \
ra/fsp/src/r_agt \
ra/fsp/src/r_ctsu \
ra/fsp/src/r_dtc \
ra/fsp/src/r_elc \
ra/fsp/src/r_flash_hp \
ra/fsp/src/r_gpt \
ra/fsp/src/r_ioport \
ra/fsp/src/r_rtc \
ra/fsp/src/r_sci_uart \
ra/fsp/src/rm_touch \
ra_gen \
sil_all/algorithm \
sil_all/app \
sil_all/buffer_ring_buf \
sil_all/cnn_lib \
sil_all/filter_ma \
sil_all/filter_mdn \
sil_all/flash \
sil_all/globals \
sil_all/mlp_lib \
sil_all/protocol_atcmds \
sil_all/tick_sys \
sil_all/timer_pwm \
sil_all/timer_reset \
sil_all/timer_rtc \
sil_all/touch \
sil_all/uart_dtc \
src \

