################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/bsp/mcu/all/bsp_clocks.c \
../ra/fsp/src/bsp/mcu/all/bsp_common.c \
../ra/fsp/src/bsp/mcu/all/bsp_delay.c \
../ra/fsp/src/bsp/mcu/all/bsp_group_irq.c \
../ra/fsp/src/bsp/mcu/all/bsp_guard.c \
../ra/fsp/src/bsp/mcu/all/bsp_io.c \
../ra/fsp/src/bsp/mcu/all/bsp_ipc.c \
../ra/fsp/src/bsp/mcu/all/bsp_irq.c \
../ra/fsp/src/bsp/mcu/all/bsp_macl.c \
../ra/fsp/src/bsp/mcu/all/bsp_register_protection.c \
../ra/fsp/src/bsp/mcu/all/bsp_sbrk.c \
../ra/fsp/src/bsp/mcu/all/bsp_sdram.c \
../ra/fsp/src/bsp/mcu/all/bsp_security.c 

C_DEPS += \
./ra/fsp/src/bsp/mcu/all/bsp_clocks.d \
./ra/fsp/src/bsp/mcu/all/bsp_common.d \
./ra/fsp/src/bsp/mcu/all/bsp_delay.d \
./ra/fsp/src/bsp/mcu/all/bsp_group_irq.d \
./ra/fsp/src/bsp/mcu/all/bsp_guard.d \
./ra/fsp/src/bsp/mcu/all/bsp_io.d \
./ra/fsp/src/bsp/mcu/all/bsp_ipc.d \
./ra/fsp/src/bsp/mcu/all/bsp_irq.d \
./ra/fsp/src/bsp/mcu/all/bsp_macl.d \
./ra/fsp/src/bsp/mcu/all/bsp_register_protection.d \
./ra/fsp/src/bsp/mcu/all/bsp_sbrk.d \
./ra/fsp/src/bsp/mcu/all/bsp_sdram.d \
./ra/fsp/src/bsp/mcu/all/bsp_security.d 

OBJS += \
./ra/fsp/src/bsp/mcu/all/bsp_clocks.o \
./ra/fsp/src/bsp/mcu/all/bsp_common.o \
./ra/fsp/src/bsp/mcu/all/bsp_delay.o \
./ra/fsp/src/bsp/mcu/all/bsp_group_irq.o \
./ra/fsp/src/bsp/mcu/all/bsp_guard.o \
./ra/fsp/src/bsp/mcu/all/bsp_io.o \
./ra/fsp/src/bsp/mcu/all/bsp_ipc.o \
./ra/fsp/src/bsp/mcu/all/bsp_irq.o \
./ra/fsp/src/bsp/mcu/all/bsp_macl.o \
./ra/fsp/src/bsp/mcu/all/bsp_register_protection.o \
./ra/fsp/src/bsp/mcu/all/bsp_sbrk.o \
./ra/fsp/src/bsp/mcu/all/bsp_sdram.o \
./ra/fsp/src/bsp/mcu/all/bsp_security.o 

SREC += \
sil_ultra_slow_jogging.srec 

MAP += \
sil_ultra_slow_jogging.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/bsp/mcu/all/%.o: ../ra/fsp/src/bsp/mcu/all/%.c
	$(file > $@.in,-mcpu=cortex-m33 -mthumb -mfloat-abi=hard -mfpu=fpv5-sp-d16 -Oz -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_ORDINAL=1 -DQE_TOUCH_CONFIGURATION -D_RA_CORE=CM33 -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/ra_gen" -I"." -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/ra_cfg/fsp_cfg/bsp" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/ra_cfg/fsp_cfg" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/src" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/sil_all" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/ra/fsp/inc" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/ra/fsp/inc/api" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/ra/fsp/inc/instances" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"C:/Users/USE/Desktop/SEAN_CODE/CNN_station_breathe/sleep_mcu_cnn_0416_init/cnn_mcu_v2/sil_ultra_slow_jogging - 20260109-Ver01.006/qe_gen" -std=c99 -Wno-stringop-overflow -Wno-format-truncation --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

