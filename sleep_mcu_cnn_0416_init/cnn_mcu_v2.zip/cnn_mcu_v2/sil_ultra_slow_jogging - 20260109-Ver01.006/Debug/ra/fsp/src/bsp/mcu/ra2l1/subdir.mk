################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/bsp/mcu/ra2l1/bsp_linker.c \
../ra/fsp/src/bsp/mcu/ra2l1/bsp_power.c 

C_DEPS += \
./ra/fsp/src/bsp/mcu/ra2l1/bsp_linker.d \
./ra/fsp/src/bsp/mcu/ra2l1/bsp_power.d 

OBJS += \
./ra/fsp/src/bsp/mcu/ra2l1/bsp_linker.o \
./ra/fsp/src/bsp/mcu/ra2l1/bsp_power.o 

SREC += \
sil_ultra_slow_jogging.srec 

MAP += \
sil_ultra_slow_jogging.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/bsp/mcu/ra2l1/%.o: ../ra/fsp/src/bsp/mcu/ra2l1/%.c
	$(file > $@.in,-mcpu=cortex-m23 -mthumb -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM23 -D_RA_ORDINAL=1 -I"H:/sil_projects/projects/sil_ultra_slow_jogging/ra_gen" -I"." -I"H:/sil_projects/projects/sil_ultra_slow_jogging/ra_cfg/fsp_cfg/bsp" -I"H:/sil_projects/projects/sil_ultra_slow_jogging/ra_cfg/fsp_cfg" -I"H:/sil_projects/projects/sil_ultra_slow_jogging/src" -I"H:/sil_projects/projects/sil_ultra_slow_jogging/sil_all" -I"H:/sil_projects/projects/sil_ultra_slow_jogging/ra/fsp/inc" -I"H:/sil_projects/projects/sil_ultra_slow_jogging/ra/fsp/inc/api" -I"H:/sil_projects/projects/sil_ultra_slow_jogging/ra/fsp/inc/instances" -I"H:/sil_projects/projects/sil_ultra_slow_jogging/ra/arm/CMSIS_6/CMSIS/Core/Include" -std=c99 -Wno-stringop-overflow -Wno-format-truncation --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

