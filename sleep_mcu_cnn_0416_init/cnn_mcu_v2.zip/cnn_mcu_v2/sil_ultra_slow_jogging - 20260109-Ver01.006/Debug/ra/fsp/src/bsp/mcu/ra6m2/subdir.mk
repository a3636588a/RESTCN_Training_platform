################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/bsp/mcu/ra6m2/bsp_linker.c 

C_DEPS += \
./ra/fsp/src/bsp/mcu/ra6m2/bsp_linker.d 

OBJS += \
./ra/fsp/src/bsp/mcu/ra6m2/bsp_linker.o 

SREC += \
sil_ultra_slow_jogging.srec 

MAP += \
sil_ultra_slow_jogging.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/bsp/mcu/ra6m2/%.o: ../ra/fsp/src/bsp/mcu/ra6m2/%.c
	$(file > $@.in,-mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O0 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_ORDINAL=1 -D_RA_CORE=CM4 -DQE_TOUCH_CONFIGURATION -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra_gen" -I"." -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra_cfg/fsp_cfg/bsp" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra_cfg/fsp_cfg" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/src" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/sil_all" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/fsp/inc" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/fsp/inc/api" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/fsp/inc/instances" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"H:/sil_projects/prj_ultra_slow_jogging/sil_ultra_slow_jogging/qe_gen" -std=c99 -Wno-stringop-overflow -Wno-format-truncation --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

